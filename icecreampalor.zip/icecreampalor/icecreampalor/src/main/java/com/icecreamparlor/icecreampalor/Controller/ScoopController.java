package com.icecreamparlor.icecreampalor.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.icecreamparlor.icecreampalor.Entity.Scoops;
import com.icecreamparlor.icecreampalor.Service.ScoopsService;



@RestController

public class ScoopController {
	@Autowired
	private ScoopsService scoopsService;
	
	@PostMapping("/addScoops")
	public Scoops postDetails(@RequestBody Scoops scoops) {
		System.out.println(scoops);
		return scoopsService.saveDetails(scoops);
		
	}
	}


