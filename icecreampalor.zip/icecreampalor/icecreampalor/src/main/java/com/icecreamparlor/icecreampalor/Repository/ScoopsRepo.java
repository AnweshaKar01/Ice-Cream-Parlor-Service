package com.icecreamparlor.icecreampalor.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.icecreamparlor.icecreampalor.Entity.Scoops;

public interface ScoopsRepo  extends JpaRepository<Scoops, Integer>{
	
	
}
