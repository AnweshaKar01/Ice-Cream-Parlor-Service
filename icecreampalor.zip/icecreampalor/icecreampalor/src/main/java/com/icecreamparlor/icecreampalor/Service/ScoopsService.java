package com.icecreamparlor.icecreampalor.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icecreamparlor.icecreampalor.Entity.Scoops;
import com.icecreamparlor.icecreampalor.Repository.ScoopsRepo;

@Service
public class ScoopsService {
	
	@Autowired
	private ScoopsRepo scoopsRepo;
	
	public Scoops saveDetails(Scoops scoops) {
		
		return scoopsRepo.save(scoops);
		
	}
}
