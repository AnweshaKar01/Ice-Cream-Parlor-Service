import React,{useState} from 'react'
import Button from '../UI/Button'
import CartButton from '../Cart/CartButton'
import classes from './Header.module.css'
const Header = (props) => {
    
  return (
    <header className={classes['scoops-nav']}>
        <div className={classes['scoops-h1']}>
            <h1>Flavoreats </h1></div>
        <CartButton onClick={props.onShowCart}/>
        <div className={classes['scoops-login']}>
           <Button onClick={props.onShowLogin}>Login</Button></div>
        </header>
  )
}

export default Header
