import React from 'react'
import { Login } from '../Login/Login';
import { Cart } from '../Cart/Cart';
import { Link, Route, Routes } from 'react-router-dom'
import Button from '../UI/Button';
import classes from './Routing.module.css'

const Routing = () => {
  //   const [isClicked,setClicked]=useState(false);
  // const changeColour=(event)=>{

  //     setClicked(event.target.style.backgroundColor="green");

  // }
  return (
    <>
      <div className={classes.login}>
        <Link className={classes.link} to="/login">
          <Button >Login</Button>
        </Link></div>

      <div className={classes.login}>
        <Link className={classes.link} to="/cart">
          <Button >Cart</Button>
        </Link>
        <Routes>
        
          <Route exact path="/login" element={<Login />} />
          <Route exact path="/cart" component={<Cart />} />
        </Routes>

      </div></>
  )
}

export default Routing