import React, { useState } from 'react'
import Card from '../UI/Card';
import classes from './Login.module.css'
import Button from '../UI/Button';
export const Login = (props) => {
  const [isName,setName]=useState(''); 
  const [isemail,setemail]=useState('');
  const [isPhoneNo,setPhoneNo]=useState('');
  const [isPassword,setPassword]=useState('');

  const nameChangeHandler=event=>setName(event.target.value);
  const emailChangeHandler=event=>setemail(event.target.value);
  const phoneNoChangeHandler=event=>setPhoneNo(event.target.value);
  const passwordChangeHandler=event=>setPassword(event.target.value);

const onSubmitHandler=(event)=>{
  event.preventDefault();
  setName('');
  setemail('');
  setPhoneNo('');
  setPassword('');
}
  return (
  <div className={classes.backdrop}  >
   
     <Card className={classes.modal} >

      <header className={classes.header}>
      <div style={{marginTop:'0'}}>
        <button onClick={props.onHideLogin}>X</button>
        </div>  
       <h2>Login Here</h2>
      </header>

      <div style={{marginLeft:'150px'}}>
       
       <form onSubmit={onSubmitHandler}> 
       <table >
        <tbody>  <tr>
            <td>Name:</td>
            <td><input type='text'  
            value={isName} 
            id ='name' onChange={nameChangeHandler}/></td>
          </tr>

          <tr>
            <td>Email Id:</td>
            <td><input type='email'
             value={isemail} 
             id ='email' onChange={emailChangeHandler}/></td>
          </tr>
          <tr>
            <td>Phone No.:</td>
            <td><input type='text' 
            value={isPhoneNo} 
            id ='phNo' onChange={phoneNoChangeHandler} /></td>
          </tr>

          <tr>
            <td>Password:</td>
            <td><input type='password' 
            value={isPassword} 
            id ='password' onChange={passwordChangeHandler}/></td>
          </tr>
          </tbody>
        </table>
        </form>
      </div>
      <footer className={classes.action}>
        <Button type='submit' >Login</Button>
        </footer>
    </Card>
    
    </div>
  );
}
