import React, { useState } from 'react'
import Card from '../UI/Card';
import classes from './Login.module.css'
export const Login = () => {
  //const [isName,setName]=useState(''); check lecture 115
  return (<div className={classes.backdrop}>
   <div> <Card className={classes.modal}>
      <header className={classes.header}>
        <h2>Login Here</h2>
      </header>
      <div style={{marginLeft:'150px'}}>
        <table >
          <tr>
            <td>Name:</td>
            <td><input type='text' placeholder='name' id ='name'/></td>
          </tr>
          <tr>
            <td>email Id:</td>
            <td><input type='email' placeholder='email' id ='email'/></td>
          </tr>
          <tr>
            <td>Phone No.:</td>
            <td><input type='number' placeholder='phNo.' id ='phNo'/></td>
          </tr>
          <tr>
            <td>Password:</td>
            <td><input type='password' placeholder='password' id ='password'/></td>
          </tr>
        </table>
      </div>
      <footer className={classes.action}>
        <button >Login</button></footer>
    </Card></div></div>
  );
}
