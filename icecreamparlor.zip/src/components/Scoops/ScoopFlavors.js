import './ScoopFlavors.css'
import Card from '../UI/Card';
import ScoopFlavorsItem from './ScoopFlavorsItem';
//import { Login } from '../UI/Login';
const ScoopFlavors = (props) => {
    return (
        <div className='screen-disp'>
            
          <ul > 
            <Card className='scoops'>
                {props.items.map(scoops=>(
                  <ScoopFlavorsItem
                  title={scoops.title}
                    amount={scoops.amount}
                    price={scoops.price}/>)
                )}
            {/* <footer>
              <button className='scoops-add-btn'>Add to Cart</button>
            </footer> */}
            </Card></ul>
            
            
        </div>


    );

};
export default ScoopFlavors;