import Card from '../UI/Card';
import './ScoopFlavorsItem.css';
import Input from '../UI/Input';
function ScoopFlavorsItem(props) {

    return (

        <Card className='scoop-item'>

            <div className='scoop-item__description'>
                <div className='scoop-title' ><h2>{props.title}</h2></div>


                <div className='scoop-item__price'>₹{props.price.toFixed(2)}</div>
                <div className='scoop-amount'><h2>{props.amount}</h2></div>

                <Input label="Amount"
                    input={{
                        id: 'amount',
                        type: "number",
                        min: '0',
                        max: '5',
                        step: '1',
                        defaultValue: '0'
                    }}
                />
                <button>+ Add</button>


            </div>

        </Card>);
};
export default ScoopFlavorsItem;