import Card from '../UI/Card';
import './ScoopFlavorsItem.css';
function ScoopFlavorsItem(props){
    
    return (
    
        <Card className='scoop-item'>
            
            <div className='scoop-item__description'>
               <div className='scoop-title' ><h2>{props.title}</h2></div>
              
                
                <div className='scoop-item__price'>${props.price}</div>
                <div className='scoop-amount'><h2>{props.amount}</h2></div>
                
                    <select className='scoop-qty'>
                    <option value='1'>1</option>
                    <option value='2'>2</option>
                    <option value='3'>3</option>
                    
                </select>
                
                
            </div>
            
        </Card>);
};
export default ScoopFlavorsItem;