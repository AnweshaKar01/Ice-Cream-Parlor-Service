import React from 'react'

export const Cart = () => {
  return (
    
      <h1>Cart</h1>
    
  )
}

