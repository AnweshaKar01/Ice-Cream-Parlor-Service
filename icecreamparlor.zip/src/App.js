import React ,{useState}from 'react';
import ScoopFlavors from './components/Scoops/ScoopFlavors';
import './App.css';
import Button from './components/UI/Button';
import Header from './components/Layout/Header';
import { Login } from './components/Login/Login';
import Cart from './components/Cart/Cart';

function App() {
  const scoopflavors = [
    {
      id: 'ice1',
      title: 'Vanilla Moon',
      price: 75.00,
      amount: '50gm/scoop',
    },

    {
      id: 'ice2',
      title: 'Belgium Chocolate',
      price: 98.00,
      amount: '50gm/scoop',
    },
    {
      id: 'ice3',
      title: 'Alphanso Mango',
      price: 105.50,
      amount: '50gm/scoop',
    },
    {
      id: 'ice4',
      title: 'Strawberry Delight',
      price: 62.55,
      amount: '50gm/scoop',
    },
    {
      id: 'ice5',
      title: 'Black Current',
      price: 99.15,
      amount: '50gm/scoop',
    },
    {
      id: 'ice6',
      title: 'Butter Scotch',
      price: 120.05,
      amount: '50gm/scoop',
    },
    {
      id: 'ice7',
      title: 'Red Velvet Oreo',
      price: 130.00,
      amount: '50gm/scoop',
    },
    {
      id: 'ice8',
      title: 'Blue Heaven',
      price: 112.00,
      amount: '50gm/scoop',
    },
  ];

  const [isLoginClicked,setLoginClicked]=useState(false);
  const showLoginHandler=()=>{
    setLoginClicked(true);
  }
  const hideLoginHandler=()=>{
    setLoginClicked(false);
  }

  const [isCartClicked,setCartClicked]=useState(false);
  const showCartHandler=()=>{
    setCartClicked(true);
  }
  const hideCartHandler=()=>{
    setCartClicked(false);
  }
  
  return (
    <div className='App'>
     { isLoginClicked && <Login onHideLogin={hideLoginHandler}/>}
     {isCartClicked && <Cart onHideCart={hideCartHandler}/>}
      <Header onShowLogin={showLoginHandler} onShowCart={showCartHandler}/>
        <div className='App'>  
      <ScoopFlavors items={scoopflavors}></ScoopFlavors>
    <footer> <Button type="submit" >Place Order</Button></footer></div>
    </div>
  );
}

export default App;