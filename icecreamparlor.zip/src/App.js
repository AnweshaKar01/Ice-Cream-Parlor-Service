import React from 'react';
import ScoopFlavors from './components/Scoops/ScoopFlavors';
import './App.css';
import Routing from './components/RoutingLinks/Routing';
import Button from './components/UI/Button';

function App() {
  const scoopflavors = [
    {
      id: 'ice1',
      title: 'Vanilla Moon',
      price: 10.25,
      amount: '50gm/scoop',
    },

    {
      id: 'ice2',
      title: 'Belgium Chocolate',
      price: 50.75,
      amount: '50gm/scoop',
    },
    {
      id: 'ice3',
      title: 'Alphanso Mango',
      price: 20.50,
      amount: '50gm/scoop',
    },
    {
      id: 'ice4',
      title: 'Strawberry Delight',
      price: 12.55,
      amount: '50gm/scoop',
    },
    {
      id: 'ice5',
      title: 'Black Current',
      price: 19.15,
      amount: '50gm/scoop',
    },
    {
      id: 'ice6',
      title: 'Butter Scotch',
      price: 20.05,
      amount: '50gm/scoop',
    },
    {
      id: 'ice7',
      title: 'Red Velvet Oreo',
      price: 30.00,
      amount: '50gm/scoop',
    },
    {
      id: 'ice8',
      title: 'Blue Heaven',
      price: 25.75,
      amount: '50gm/scoop',
    },
  ];

  // const addScoopHandler=(scoop)=>{
  //   console.log('In App.js');
  //   console.log(scoop);
  // };
  
  return (
    <>
      <header className='scoops-nav'>
        <div className='scoops-h1'><h1>Flavoreats </h1></div>
         <Routing/>
        </header>
        <div className='App'>  
      <ScoopFlavors items={scoopflavors}></ScoopFlavors>
    <footer> <Button type="submit" >Place Order</Button></footer></div>
    </>
  );
}

export default App;